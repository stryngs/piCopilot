# kSnarf
kSnarf was conceived as a tool for FOSS Intelligence Gathering of the 802.11 spectrum.</br></br>
kSnarf is not the first of it's kind.  Many other such tools do the exact same thing.</br></br>
The idea behind kSnarf is to keep it alive as a project and community asset.</br>
FOSS tools like kSnarf start off initially strong, but then support dies for them.  So long as this repo exists, kSnarf will be considered under active development and PRs are highly encouraged.</br></br>
This initial release is more of a proof of concept than anything.  Modules are being actively developed, but have yet to be released.  When they are ready, they will be pushed accordingly.
